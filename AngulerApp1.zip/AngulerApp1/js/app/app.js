﻿/// <reference path="../angular.min.js" />

var app = angular.module("realApp", ['ngRoute']);

app.config(function ($routeProvider) {
    $routeProvider
        .when('/home', {
            controller: 'homeController',
            templateUrl: '/partials/home.html'
        })
        .when('/login', {
            controller: 'loginController',
            templateUrl: '/partials/Login.html'
        })
        .when('/realistQ', {
            controller: 'realistController',
            templateUrl: '/partials/RealistQ.html'
        })
        .when('/urlTest', {
            controller: 'urlcontroller',
            templateUrl: '/partials/urlValidation.html'
        })
        .otherwise({ redirectTo: '/home' });
});


app.controller("homeController", ['$scope', function ($scope, $http) {
    $scope.message = "dp";
    // document.location = "#/accounts";
    $scope.gotoNext = function () {
        document.location = "#!/login";
    };
}]);
app.controller("realistController", ['$scope', function ($scope, $http) {
    $scope.returnTologins = function () {
        document.location = "#!/login";
    };

}]);
app.controller("loginController", ['$scope','$http', function ($scope, $http) {
    $scope.valiadte = function () {
        $http.get("http://192.168.1.89/real/api/real/login/?email=" + $scope.email + "&pwd=" + $scope.pwd)
        .then(function (response) {
            console.log(response);
            document.location = "#!/realistQ";
            //$scope.data = response.data;
            //if (true) {

            //}
        },
        function (error) {
            console.log(error);
        })
        
    };
    $scope.email = "";
    $scope.pwd = "";
    $scope.urlTest = function () {
        document.location = "#!/urlTest";
    }
  
}]);
app.controller("urlcontroller", ['$scope', function ($scope, $http) {
    $scope.returnTologins = function () {
        document.location = "#!/login";
    };
    $scope.urlValidation = function () {
        $http.get(url)
       .then(function (response) {
           $scope.message = response.status;
       },
       function (error) {
           $scope.Error = error.status;
       }
       )
    }
}]);
app.controller("realistController", ['$scope', '$http', function ($scope, $http) {
    $scope.name = "devendra";


    init = function (){
        //debugger;
        $http.get("http://192.168.1.89/real/api/real/details/?id=12")
       .then(function (response) {
           console.log(response);
           $(".loading").hide()
           $scope.details = response.data;
           //if (true) {

           //}
       },
       function (error) {
           console.log(error);
       })
    }
    init();
}]);


